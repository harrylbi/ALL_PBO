package abstrak;

public class Mobil extends Kendaraan {
	private int kapasitasBagasi;
	
	@Override
	public void nyalakan() {
		// TODO Auto-generated method stub
		System.out.println("Mobil dinyalakan");
		
	}

}