package abstrak;

public class Truk extends Kendaraan {
	private int kapasitasBak;
	@Override
	public void nyalakan() {
		System.out.println("Truk dinyalakan.");
	}


}